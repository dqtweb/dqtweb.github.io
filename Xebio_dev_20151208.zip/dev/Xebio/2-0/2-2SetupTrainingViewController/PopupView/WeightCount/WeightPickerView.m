//
//  WeightPickerView.m
//  Xebio
//
//  Created by seesaa on 2/10/15.
//  Copyright (c) 2015 seesaa. All rights reserved.
//

#import "WeightPickerView.h"

@interface WeightPickerView()
<
    UIPickerViewDelegate,
    UIPickerViewDataSource
>

@property (assign, nonatomic) BOOL userConfirmOver; //tungdq
@property (strong, nonatomic) NSArray *hundredData;
@property (strong, nonatomic) NSMutableArray *countData;
@property (weak, nonatomic) IBOutlet UILabel *weightLabel;
@property (weak, nonatomic) IBOutlet UILabel *countLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *dotLayoutConstrainTraillingLeft;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *countLayoutConstrainTraillingLeft;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *distanceLayoutConstrainTrainingRight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *horizontalLayoutConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *dotLayoutConstraintBottom;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *weightLayoutConstraintBottom;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *countLayoutConstraintBottom;

@end

@implementation WeightPickerView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)initializationData
{
    self.userConfirmOver = NO;
    [self.weightLabel setText:@"ウエイトを指定してください(Kg)"];
    [self.countLabel setText:@"回数を指定してください"];
    
    self.hundredData    = @[    @[@"0",@"1",@"2",@"3",@"4",@"5",@"-1",@"-1",@"-1",@"-1"],
                                @[@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9"],
                                @[@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9"],
                                @[@"0",@"5",@"-1",@"-1",@"-1",@"-1",@"-1",@"-1",@"-1",@"-1"]
                            ];
    self.countData = [NSMutableArray array];
    
    for (int i = 1;i< 10000;i++)
    {
        NSNumber* number = [NSNumber numberWithInt:i]; // <-- autoreleased, so you don't need to release it yourself
        [self.countData addObject:number];
    }

    self.hundredPicker.delegate = self;
    self.hundredPicker.dataSource = self;
    
    self.countPicker.delegate = self;
    self.countPicker.dataSource = self;

    self.weightResult = self.timeline.valueRecord2;
    self.numberCount = self.timeline.valueRecord1;
    self.maxWeight= self.timeline.maxValue;
    // Set default value for picker
    if (self.weightResult > 0)
    {
        int hundred = self.weightResult / 100;
        int dozen   = ((int)self.weightResult % 100)/ 10;
        int unit    = ((int)self.weightResult % 100) % 10;
        
        int sub = (((int)(self.weightResult * 10)) % 100) % 10;
        
        NSLog(@"weight %.1f count %d %d %d %d",self.weightResult,hundred,dozen,unit,sub);
        
        NSLog(@"maxWeight %d",self.maxWeight);
        
        
        [self.hundredPicker selectRow:hundred  inComponent:0 animated:NO];
        [self.hundredPicker reloadComponent:0];
        
        [self.hundredPicker selectRow:dozen  inComponent:1 animated:NO];
        [self.hundredPicker reloadComponent:1];
        
        [self.hundredPicker selectRow:unit  inComponent:2 animated:NO];
        
        [self.hundredPicker reloadComponent:2];
        
        if (sub == 0)
        {
            [self.hundredPicker selectRow:0 inComponent:3 animated:NO];
            [self.hundredPicker reloadComponent:3];
        }
        else
        {
            [self.hundredPicker selectRow:1 inComponent:3 animated:NO];
            [self.hundredPicker reloadComponent:3];
        }
        
    }
    
    [self.countPicker selectRow:self.numberCount - 1 inComponent:0 animated:NO];
    [self.countPicker reloadComponent:0];
   
    if (IS_IPHONE_5 || IS_IPHONE_4_OR_LESS)
    {
        self.dotLayoutConstrainTraillingLeft.constant = 43;
        self.countLayoutConstrainTraillingLeft.constant = 90;
        
        self.distanceLayoutConstrainTrainingRight.constant = 20;
        self.horizontalLayoutConstraint.constant = 10;
        
        self.countLayoutConstraintBottom.constant = 82;
        self.dotLayoutConstraintBottom.constant = 90;
        self.weightLayoutConstraintBottom.constant = 80;
        if (IS_IOS8_OR_ABOVE)
        {
            self.dotLayoutConstraintBottom.constant = 90;
            self.weightLayoutConstraintBottom.constant = 80;
        }
        else
        {
            self.dotLayoutConstraintBottom.constant = 60;
            self.weightLayoutConstraintBottom.constant = 50;
        }
    }
    else if (IS_IPHONE_6)
    {
        self.countLayoutConstrainTraillingLeft.constant = 120;
        self.dotLayoutConstrainTraillingLeft.constant = 57;
    }
}

- (void)drawRect:(CGRect)rect
{
    // Drawing code
    
    [self.backButton setEnabled:self.weightView.hidden];
    
    [self.forwardButton setEnabled:!self.backButton.enabled];
    
    [self initializationData];
}


- (IBAction)backAction:(id)sender
{
    if ([self anySubViewScrolling:self]) return;
    
    /*
    if (self.weightView.hidden)
    {
        if (![self checkConditionMaxValue])
        {
            return;
        }
        self.weightView.hidden = NO;
        self.countView.hidden = YES;
        [self.backButton setEnabled:NO];
        [self.forwardButton setEnabled:YES];
    }
    else
    {
        self.weightView.hidden = YES;
        self.countView.hidden = NO;
        [self.backButton setEnabled:YES];
        [self.forwardButton setEnabled:NO];
    }
     */
    
    if (self.weightView.hidden)
    {
        [self checkConditionMaxValue:@"backAction" withNextSelector:@selector(switchToWeightView)];
    }
    else
    {
        [self switchToCountView];
    }
}

- (IBAction)forwardAction:(id)sender
{
    if ([self anySubViewScrolling:self]) return;
    
    /*
    if (self.weightView.hidden)
    {
        self.weightView.hidden = NO;
        self.countView.hidden = YES;
        [self.backButton setEnabled:NO];
        [self.forwardButton setEnabled:YES];
    }
    else
    {
        if (![self checkConditionMaxValue])
        {
            return;
        }
        
        self.weightView.hidden = YES;
        self.countView.hidden = NO;
        [self.backButton setEnabled:YES];
        [self.forwardButton setEnabled:NO];
    }
     */
    
    if (self.weightView.hidden)
    {
        [self switchToWeightView];
    }
    else
    {
        [self checkConditionMaxValue:@"forwardAction" withNextSelector:@selector(switchToCountView)];
    }
}

- (IBAction)doneAction:(id)sender
{

    DLog(@"new weight %.1f newcount %d",self.weightResult,self.numberCount);
    
    /*
    //[self checkConditionMaxValue];
    BOOL checkCondition = [self checkConditionMaxValue];
    
    if (!checkCondition) return;
    
    if ([self.delegate respondsToSelector:@selector(tapToDoneButtonInTimeLine:atIndexPath:)])
    {
        self.timeline.valueRecord2 = self.weightResult;
        self.timeline.valueRecord1 = self.numberCount;
        NSLog(@"indexPath %@",self.indexPath);
        [self.delegate tapToDoneButtonInTimeLine:self.timeline atIndexPath:self.indexPath];
    }
     */
    
    //tungdq
    [self checkConditionMaxValue:@"doneAction" withNextSelector:@selector(saveTimeLine)];
}

// tungdq
- (void)saveTimeLine
{
    if ([self.delegate respondsToSelector:@selector(tapToDoneButtonInTimeLine:atIndexPath:)])
    {
        self.timeline.valueRecord2 = self.weightResult;
        self.timeline.valueRecord1 = self.numberCount;
        NSLog(@"indexPath %@",self.indexPath);
        [self.delegate tapToDoneButtonInTimeLine:self.timeline atIndexPath:self.indexPath];
    }
}

// switch to countView
- (void)switchToCountView
{
    self.weightView.hidden = YES;
    self.countView.hidden = NO;
    [self.backButton setEnabled:YES];
    [self.forwardButton setEnabled:NO];
}

// switch to weightView
- (void)switchToWeightView
{
    self.weightView.hidden = NO;
    self.countView.hidden = YES;
    [self.backButton setEnabled:NO];
    [self.forwardButton setEnabled:YES];
}

// new check condition with confirm
- (void)checkConditionMaxValue:(NSString *)methodName withNextSelector:(SEL)selector
{
    NSLog(@"______ checkResultCondition > trainingType=%d", self.timeline.trainingType);
    int trainingtype = self.timeline.trainingType;
    
    // avoid confirm multiple time on other view
    if (self.weightView.hidden == YES) {
        self.userConfirmOver = YES;
    } else {
        self.userConfirmOver = NO;
    }
    
    // for setting input
    if (trainingtype == 0)
    {
        NSLog(@"___ numberCount: %d", self.numberCount);
        NSLog(@"___ maxWeight: %d", self.maxWeight);
        
        if (self.numberCount > self.maxWeight || self.numberCount < 1)
        {
            NSString *mess = [NSString stringWithFormat:@"1回〜%d回の間で入力して下さい。",self.maxWeight];
            
            UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"回数を指定してください"
                                                               message:mess
                                                              delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [av show];
        }
        else
        {
            [self performSelector:selector];
        }
    }
    else
    {
        NSLog(@"___ newMetValue: %f", self.weightResult);
        NSLog(@"___ maxWeight: %d", self.maxWeight);
        
        // if user already confirm
        if (self.userConfirmOver) {
            [self performSelector:selector];
            return;
        }
        
        // normal check
        if (self.weightResult > self.maxWeight || self.weightResult < 1)
        {
            __block BOOL userConfirm = NO;
            
            NSString *mess = [NSString stringWithFormat:@"1kg〜%dkgが適正値です。よろしいですか？", self.maxWeight];
            UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"ウエイト入力"
                                                         message:mess
                                                        delegate:self
                                               cancelButtonTitle:@"キャンセル"
                                               otherButtonTitles:@"OK", nil];
            
            av.alertViewStyle = UIAlertViewStyleDefault;
            av.tapBlock = ^(UIAlertView *alertView, NSInteger buttonIndex) {
                if (buttonIndex == alertView.firstOtherButtonIndex) {
                    userConfirm = YES;
                    self.userConfirmOver = YES;
                } else if (buttonIndex == alertView.cancelButtonIndex) {
                    userConfirm = NO;
                }
            };
            
            av.didDismissBlock = ^(UIAlertView *alertView, NSInteger buttonIndex) {
                if (userConfirm) {
                    [self performSelector:selector];
                }
            };
            
            [av show];
        } else {
            [self performSelector:selector];
        }
    }
}

- (BOOL)checkConditionMaxValue
{
    int trainingtype = self.timeline.trainingType;
    if (trainingtype == 0)
    {
        if (self.numberCount > self.maxWeight || self.numberCount < 1)
        {
            NSString *mess = [NSString stringWithFormat:@"1回〜%d回の間で入力して下さい。",self.maxWeight];
            
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"回数を指定してください"
                                                               message:mess
                                                              delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alertView show];
            return NO;

        }
    }
    else
    {
        if (self.weightResult > self.maxWeight || self.weightResult < 1)
        {
            NSString *message = [NSString stringWithFormat:@"1kg〜%dkgの間で入力して下さい。",self.maxWeight];
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"ウエイト入力" message:message
                                                              delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            
            [alertView show];
            return NO;
        }

    }
    return YES;
}

#pragma mark - UIPickerDelegate

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    if (pickerView.tag ==1)
    {
        return 4;
    }
    else
    {
        return 1;
    }

}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (pickerView.tag == 1)
    {
        if (component ==0)
        {
            return 6;
        }
        else if (component == 1)
        {
            return 10;
        }
        else if (component == 2)
        {
            return 10;
        }
        else
        {
            return 2;
        }
    }
    else
    {
        return _countData.count;
    }


}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (pickerView.tag == 1)
    {
        return _hundredData[component][row];
    }
    else
    {
        NSString *str = [NSString stringWithFormat:@"%@",[NSNumber numberWithInt:[_countData[row]intValue]]];
        
        return str;
    }

}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if (pickerView.tag == 1)
    {
        if (self.timeline.valueRecord2 > 0)
        {
            float hundredValue      = (float)[pickerView selectedRowInComponent:0];
            float dozenValue        = (float)[pickerView selectedRowInComponent:1];
            float unitValue         = (float)[pickerView selectedRowInComponent:2];
            float subValue          = (float)[pickerView selectedRowInComponent:3];
            NSLog(@" %f %f %f %f",hundredValue,dozenValue,unitValue,subValue);
            self.weightResult = hundredValue * 100 + dozenValue * 10 + unitValue + subValue * 0.5;
        }

    }
    else
    {
        int number = (float)[pickerView selectedRowInComponent:0];
        self.numberCount = number + 1;
    }
}

-(bool) anySubViewScrolling:(UIView*)view
{
    if( [ view isKindOfClass:[ UIScrollView class ] ] )
    {
        UIScrollView* scroll_view = (UIScrollView*) view;
        if( scroll_view.dragging || scroll_view.decelerating )
        {
            return true;
        }
    }
    
    for( UIView *sub_view in [ view subviews ] )
    {
        if( [ self anySubViewScrolling:sub_view ] )
        {
            return true;
        }
    }
    
    return false;
}
@end
