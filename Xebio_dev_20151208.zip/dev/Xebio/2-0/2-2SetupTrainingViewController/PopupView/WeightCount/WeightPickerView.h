//
//  WeightPickerView.h
//  Xebio
//
//  Created by seesaa on 2/10/15.
//  Copyright (c) 2015 seesaa. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIAlertView+Blocks.h" //tungdq

@class Timeline;

@protocol WeightPickerViewDelegate <NSObject>
//- (void) tapToDoneButtonInTimelineID:(int)timelineID withNewWeight:(float)newWeight newCount:(int)newCount;
- (void) tapToDoneButtonInTimeLine:(Timeline *)timeline atIndexPath:(NSIndexPath *)indexPath;
@end

@interface WeightPickerView : UIView

@property (weak, nonatomic) id<WeightPickerViewDelegate> delegate;

@property (weak, nonatomic) IBOutlet UIButton *backButton;
@property (weak, nonatomic) IBOutlet UIButton *forwardButton;
@property (weak, nonatomic) IBOutlet UIButton *doneButton;

@property (weak, nonatomic) IBOutlet UIView *countView;
@property (weak, nonatomic) IBOutlet UIView *weightView;
@property (weak, nonatomic) IBOutlet UIPickerView *hundredPicker;
@property (weak, nonatomic) IBOutlet UIPickerView *countPicker;

@property (assign, nonatomic) int   maxWeight;
@property (assign, nonatomic) float weightResult;
@property (assign, nonatomic) int   numberCount;
@property (assign, nonatomic) int   timelineID;

@property (strong ,nonatomic) Timeline *timeline;
@property (strong ,nonatomic) NSIndexPath *indexPath;

@end
