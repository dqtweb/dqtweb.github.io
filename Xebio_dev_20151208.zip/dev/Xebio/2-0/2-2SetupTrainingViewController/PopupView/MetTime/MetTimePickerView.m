//
//  MetTimePickerView.m
//  Xebio
//
//  Created by seesaa on 3/3/15.
//  Copyright (c) 2015 seesaa. All rights reserved.
//

#import "MetTimePickerView.h"
#import "CommonHelper.h"

@interface MetTimePickerView()
<
    UIPickerViewDataSource,
    UIPickerViewDelegate
>

@property (assign, nonatomic) BOOL userConfirmOver;

@property (strong, nonatomic) NSArray *metData;
@property (strong, nonatomic) NSArray *timeData;

@property (assign, nonatomic) float newMetValue;
@property (assign, nonatomic) int newTimeValue;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *timeHorizontalSpaceLeft;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *metLayoutConstrainTraillingLeft;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *metLayoutConstraintBottom;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *distanceLayoutConstrainTrainingRight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *horizontalLayoutConstraint;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *minutesLayoutConstraintTop;


@end

@implementation MetTimePickerView


// Only override drawRect: if you perform custom drawing.
- (void)initialization
{
    DLog(@"timelineid %d workigdID %d",self.timeline.trainingID,self.timeline.workoutTrainingID);
    
    self.userConfirmOver = NO; //tungdq
    
    self.metPickerView.delegate = self;
    self.metPickerView.dataSource = self;
    
    self.timePickerView.delegate = self;
    self.timePickerView.dataSource = self;
    
    
    self.metData = @[ @[@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9"],
                      @[@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9"],
                      @[@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9"],
                      @[@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9"],
                      @[@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9"]
                         ];
    self.timeData  =@[ @[@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10"],
                       @[@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9"],
                       @[@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9"]];
    
    
    [self setDefaultValueInPickerView];
    
    if (IS_IPHONE_5 || IS_IPHONE_4_OR_LESS)
    {
        self.timeHorizontalSpaceLeft.constant = 10;
        self.metLayoutConstrainTraillingLeft.constant = 8;

        self.distanceLayoutConstrainTrainingRight.constant = 20;
        self.horizontalLayoutConstraint.constant = 10;
        if (IS_IOS8_OR_ABOVE)
        {
            self.metLayoutConstraintBottom.constant = 94;
        }
        else
        {
            self.metLayoutConstraintBottom.constant = 68;
        }
        
        self.minutesLayoutConstraintTop.constant = 55;
    }
    else if (IS_IPHONE_6 || IS_IPHONE_6P)
    {
        self.timeHorizontalSpaceLeft.constant = 40;
        self.metLayoutConstrainTraillingLeft.constant = 10;
    }

    
}
- (void)setDefaultValueInPickerView
{
    if (self.timeline.trainingType == 2)
    {
        // set M + time
        [self setDefaultMetPickerWithValue:self.timeline.valueRecord2];
        [self setDefaultTimePickerWithValue:self.timeline.valueRecord1];
        self.newMetValue = self.timeline.valueRecord2;
        self.newTimeValue = self.timeline.valueRecord1;
    }
    else if (self.timeline.trainingType == 3 )
    {
        // m
        [self setDefaultMetPickerWithValue:self.timeline.valueRecord1];
        self.newMetValue = self.timeline.valueRecord1;
    }
    else
    {
        [self setDefaultTimePickerWithValue:self.timeline.valueRecord1];
        self.newTimeValue = self.timeline.valueRecord1;
    }
}
- (void)setDefaultMetPickerWithValue:(float)inputvalue
{
 
    int dozenThousandValue = inputvalue / 10000;
    int thousandValue = ((int)inputvalue % 10000) / 1000;
    int hundredValue = ((int)inputvalue % 1000) / 100;
    int dozenValue = ((int)inputvalue % 1000) % 100 / 10;
    int unitValue = ((((int)inputvalue % 1000) % 100) %10);
    
    [self.metPickerView selectRow:dozenThousandValue inComponent:0 animated:NO];
    [self.metPickerView reloadComponent:0];
    
    [self.metPickerView selectRow:thousandValue inComponent:1 animated:NO];
    [self.metPickerView reloadComponent:1];
    
    [self.metPickerView selectRow:hundredValue inComponent:2 animated:NO];
    [self.metPickerView reloadComponent:2];
    
    [self.metPickerView selectRow:dozenValue inComponent:3 animated:NO];
    [self.metPickerView reloadComponent:3];
    
    [self.metPickerView selectRow:unitValue inComponent:4 animated:NO];
    [self.metPickerView reloadComponent:4];
}

- (void)setDefaultTimePickerWithValue:(int)inputvalue
{
    int hour = inputvalue  / 60;
    int minutes  = ((inputvalue) % 60) / 10;
    int subminutes = ((inputvalue) % 60) % 10;
    
    [self.timePickerView selectRow:hour inComponent:0 animated:NO];
    [self.timePickerView reloadComponent:0];
    
    [self.timePickerView selectRow:minutes inComponent:1 animated:NO];
    [self.timePickerView reloadComponent:1];
    
    [self.timePickerView selectRow:subminutes inComponent:2 animated:NO];
    [self.timePickerView reloadComponent:2];

}
- (void)drawRect:(CGRect)rect {
    // Drawing code
    [self initialization];
    
    [self.backBtn setEnabled:self.metView.hidden];
    
    [self.forwardBtn setEnabled:!self.backBtn.enabled];
}

- (IBAction)backAction:(id)sender
{
    if ([self anySubViewScrolling:self]) return;
    
    /*
    if (self.metView.hidden)
    {
        if (![self checkResultCondition])
        {
            return;
        }
        
        self.metView.hidden = NO;
        self.timeView.hidden = YES;
        [self.backBtn setEnabled:NO];
        [self.forwardBtn setEnabled:YES];
    }
    else
    {
        self.metView.hidden = YES;
        self.timeView.hidden = NO;
        [self.backBtn setEnabled:YES];
        [self.forwardBtn setEnabled:NO];
    }
     */
    
    if (self.metView.hidden)
    {   
        [self checkResultCondition:@selector(switchToMetView)];
    }
    else
    {
        [self switchToTimeView];
    }
}

//tungdq
- (void)switchToMetView
{
    self.metView.hidden = NO;
    self.timeView.hidden = YES;
    [self.backBtn setEnabled:NO];
    [self.forwardBtn setEnabled:YES];
}

//tungdq
- (void)switchToTimeView
{
    self.metView.hidden = YES;
    self.timeView.hidden = NO;
    [self.backBtn setEnabled:YES];
    [self.forwardBtn setEnabled:NO];
}

- (IBAction)forwardAction:(id)sender
{
    if ([self anySubViewScrolling:self]) return;
    
    /*
    if (self.metView.hidden)
    {
        self.metView.hidden = NO;
        self.timeView.hidden = YES;
        [self.backBtn setEnabled:NO];
        [self.forwardBtn setEnabled:YES];
    }
    else
    {
        if (![self checkResultCondition])
        {
            return;
        }
        self.metView.hidden = YES;
        self.timeView.hidden = NO;
        [self.backBtn setEnabled:YES];
        [self.forwardBtn setEnabled:NO];
    }
     */
    
    //tungdq
    if (self.metView.hidden)
    {
        [self switchToMetView];
    }
    else
    {
        [self checkResultCondition:@selector(switchToTimeView)];
    }
}

- (IBAction)doneAction:(id)sender
{
    /*
    BOOL isOK = [self checkResultCondition];
    if (isOK)
    {
        if ([self.delegate respondsToSelector:@selector(tapToDoneButtonFrom:withTimeline:atIndexPath:)]) {
            if (self.timeline.trainingType == 2)
            {
                self.timeline.valueRecord2 = self.newMetValue;
                self.timeline.valueRecord1 = self.newTimeValue;
            }
            else if (self.timeline.trainingType == 3)
            {
                self.timeline.valueRecord1 = self.newMetValue;
                self.timeline.valueRecord2 = -1;
            }
            else
            {
                self.timeline.valueRecord1 = self.newTimeValue;
                self.timeline.valueRecord2 = -1;
            }
            [self.delegate tapToDoneButtonFrom:self withTimeline:self.timeline atIndexPath:self.indexPath];
        }
    }
     */
    
    [self checkResultCondition:@selector(saveTimeLine)];
}

//tungdq
- (void)saveTimeLine
{
    if ([self.delegate respondsToSelector:@selector(tapToDoneButtonFrom:withTimeline:atIndexPath:)]) {
        if (self.timeline.trainingType == 2)
        {
            self.timeline.valueRecord2 = self.newMetValue;
            self.timeline.valueRecord1 = self.newTimeValue;
        }
        else if (self.timeline.trainingType == 3)
        {
            self.timeline.valueRecord1 = self.newMetValue;
            self.timeline.valueRecord2 = -1;
        }
        else
        {
            self.timeline.valueRecord1 = self.newTimeValue;
            self.timeline.valueRecord2 = -1;
        }
        [self.delegate tapToDoneButtonFrom:self withTimeline:self.timeline atIndexPath:self.indexPath];
    }
}

- (BOOL)checkResultCondition
{
    NSLog(@"______ checkResultCondition > trainingType=%d", self.timeline.trainingType);
    if (self.timeline.trainingType == 2 )
    { // met + time
        NSLog(@"___ newMetValue: %f", self.newMetValue);
        NSLog(@"___ timeline.maxValue: %d", self.timeline.maxValue);
        
        if (self.newMetValue > self.timeline.maxValue || self.newMetValue < 1)
        {
            NSLog(@"___ metValue is out of range > showConfirm");
            NSString *mess = [NSString stringWithFormat:@"1m〜%dmの間で入力して下さい",self.timeline.maxValue];
            NSString *title = @"距離入力";
            
            [self showAlertViewWithTitle:title message:mess];
            return NO;
        }
        else if (self.newTimeValue < 1 || self.newTimeValue > 659)
        {
            NSString *mess = [NSString stringWithFormat:@"1分〜659分が適正値です。よろしいですか？"];
            NSString *title = @"時間入力";
            [self showAlertViewWithTitle:title message:mess];
            return NO;
        }
    }
    else if (self.timeline.trainingType == 3)
    {
        NSLog(@"___ newMetValue: %f", self.newMetValue);
        NSLog(@"___ timeline.maxValue: %d", self.timeline.maxValue);
        
        if (self.newMetValue > self.timeline.maxValue || self.newMetValue < 1)
        {
            NSString *mess = [NSString stringWithFormat:@"1m〜%dmの間で入力して下さい",self.timeline.maxValue];
            NSString *title = @"距離入力";
            
            [self showAlertViewWithTitle:title message:mess];
            return NO;
        }
    }
    else if (self.timeline.trainingType == 4)
    {
        // time
        if (self.newTimeValue > self.timeline.maxValue || self.newTimeValue < 1)
        {
            NSString *mess = [NSString stringWithFormat:@"1分〜%d分の間で入力して下さい",self.timeline.maxValue];
            NSString *title = @"時間入力";

            [self showAlertViewWithTitle:title message:mess];
            return NO;
        }
    }

    return YES;
}


- (void)checkResultCondition:(SEL)aSelector
{
    NSLog(@"______ checkResultCondition > trainingType=%d", self.timeline.trainingType);
    
    // avoid confirm multiple time on other view
    if (self.metView.hidden == YES) {
        self.userConfirmOver = YES;
    } else {
        self.userConfirmOver = NO;
    }
    
    // if user already confirm
    if (self.userConfirmOver) {
        [self performSelector:aSelector];
        return;
    }
    
    if (self.timeline.trainingType == 2 )
    { // met + time
        //NSLog(@"___ newMetValue: %f", self.newMetValue);
        //NSLog(@"___ newTimeValue: %d", self.newTimeValue);
        //NSLog(@"___ timeline.maxValue: %d", self.timeline.maxValue);
        
        if (self.newMetValue > self.timeline.maxValue || self.newMetValue < 1)
        {
            NSString *mess = [NSString stringWithFormat:@"1m〜%dmが適正値です。よろしいですか？",self.timeline.maxValue];
            NSString *title = @"距離入力";
            
            [self showConfirmAlertViewWithTitle:title message:mess selector:aSelector];
        }
        // this case never happen?
        else if (self.newTimeValue < 1 || self.newTimeValue > 659)
        {
            NSString *mess = [NSString stringWithFormat:@"1分〜659分が適正値です。よろしいですか？"];
            NSString *title = @"時間入力";
            
            [self showConfirmAlertViewWithTitle:title message:mess selector:aSelector];
        } else {
            [self performSelector:aSelector];
        }
    }
    else if (self.timeline.trainingType == 3)
    {
        NSLog(@"___ newMetValue: %f", self.newMetValue);
        NSLog(@"___ timeline.maxValue: %d", self.timeline.maxValue);
        
        if (self.newMetValue > self.timeline.maxValue || self.newMetValue < 1)
        {
            NSString *mess = [NSString stringWithFormat:@"1m〜%dmが適正値です。よろしいですか？",self.timeline.maxValue];
            NSString *title = @"距離入力";
            
            [self showConfirmAlertViewWithTitle:title message:mess selector:aSelector];
        }
        else
        {
            [self performSelector:aSelector];
        }
    }
    else if (self.timeline.trainingType == 4)
    {
        NSLog(@"___ newTimeValue: %f", self.newTimeValue);
        NSLog(@"___ timeline.maxValue: %d", self.timeline.maxValue);
        
        // time
        if (self.newTimeValue > self.timeline.maxValue || self.newTimeValue < 1)
        {
            NSString *mess = [NSString stringWithFormat:@"1分〜%d分が適正値です。よろしいですか？",self.timeline.maxValue];
            NSString *title = @"時間入力";
            
            [self showConfirmAlertViewWithTitle:title message:mess selector:aSelector];
        }
        else
        {
            [self performSelector:aSelector];
        }
    }
}

#pragma mark - UIPickerDelegate
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    if (pickerView.tag == 1)
    {
        return 5;
    }
    else
        return 3;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (pickerView.tag == 1)
    {
        return 10;
    }
    else
    {
        if (component == 0)
        {
            return 11;
        }else if (component == 1)
        {
            return 6;
        }
        else
        {
            return 10;
        }
    }
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (pickerView.tag == 1)
    {
        return self.metData[component][row];
    }
    else
    {
        return self.timeData[component][row];
    }
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if (pickerView.tag == 1)
    {
        float tensOfThousandValue   = (float)[pickerView selectedRowInComponent:0];
        float thousandValue         = (float)[pickerView selectedRowInComponent:1];
        float hundredValue          = (float)[pickerView selectedRowInComponent:2];
        float dozenValue            = (float)[pickerView selectedRowInComponent:3];
        float unitValue             = (float)[pickerView selectedRowInComponent:4];
        
        self.newMetValue = tensOfThousandValue * 10000 + thousandValue * 1000 + hundredValue * 100 + dozenValue * 10 + unitValue;
        
        NSLog(@"newmetvalue %f",self.newMetValue);

    }
    else
    {
        int hours = (int)[pickerView selectedRowInComponent:0];
        int minutes = (int)[pickerView selectedRowInComponent:1];
        int subMinutes = (int)[pickerView selectedRowInComponent:2];
        
        self.newTimeValue = hours * 60 + minutes * 10 + subMinutes;
        
        NSLog(@"time %d",self.newTimeValue);
    }
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component
{
    if (pickerView.tag == 2)
    {
        if (component == 2)
        {
            return 30;
        }
        else
        {
            return 90;
        }
    }
    else
    {
        if (IS_IPHONE_6||IS_IPHONE_6P)
        {
            return 60;
        }
        return 50;
    }
}

- (void)showAlertViewWithTitle:(NSString *)aTitle message:(NSString*)aMessage{
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:aTitle
                          message:aMessage
                          delegate:nil
                          cancelButtonTitle:@"OK"
                          otherButtonTitles:nil, nil];
    [alert show];
}

//tungdq
- (void)showConfirmAlertViewWithTitle:(NSString *)aTitle message:(NSString *)aMessage selector:(SEL)aSelector {
    __block BOOL userConfirm = NO;
    UIAlertView *av = [[UIAlertView alloc]
                          initWithTitle:aTitle
                          message:aMessage
                          delegate:nil
                          cancelButtonTitle:@"キャンセル"
                          otherButtonTitles:@"OK", nil];
    
    av.alertViewStyle = UIAlertViewStyleDefault;
    av.tapBlock = ^(UIAlertView *alertView, NSInteger buttonIndex) {
        if (buttonIndex == alertView.firstOtherButtonIndex) {
            userConfirm = YES;
            //self.confirmOverWeight = YES;
        } else if (buttonIndex == alertView.cancelButtonIndex) {
            userConfirm = NO;
        }
    };
    
    av.didDismissBlock = ^(UIAlertView *alertView, NSInteger buttonIndex) {
        if (userConfirm) {
            [self performSelector:aSelector];
        }
    };
    [av show];
}

-(bool) anySubViewScrolling:(UIView*)view
{
    if( [ view isKindOfClass:[ UIScrollView class ] ] )
    {
        UIScrollView* scroll_view = (UIScrollView*) view;
        if( scroll_view.dragging || scroll_view.decelerating )
        {
            return true;
        }
    }
    
    for( UIView *sub_view in [ view subviews ] )
    {
        if( [ self anySubViewScrolling:sub_view ] )
        {
            return true;
        }
    }
    
    return false;
}


@end
