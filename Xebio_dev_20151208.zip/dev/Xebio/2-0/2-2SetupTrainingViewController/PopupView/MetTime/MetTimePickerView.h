//
//  MetTimePickerView.h
//  Xebio
//
//  Created by seesaa on 3/3/15.
//  Copyright (c) 2015 seesaa. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIAlertView+Blocks.h" //tungdq

@class Timeline;
@class MetTimePickerView;
@protocol MetTimePickerViewDelegate <NSObject>
//- (void) tapToDoneButtonInTimeLine:(Timeline *)timeline atIndexPath:(NSIndexPath *)indexPath;
- (void)tapToDoneButtonFrom:(MetTimePickerView *)metTimeView withTimeline:(Timeline *)timeline atIndexPath:(NSIndexPath *)indexPath;

@end
@interface MetTimePickerView : UIView

@property (assign, nonatomic) id<MetTimePickerViewDelegate>delegate;

@property (weak, nonatomic) IBOutlet UIButton *forwardBtn;
@property (weak, nonatomic) IBOutlet UIButton *backBtn;
@property (weak, nonatomic) IBOutlet UIPickerView *metPickerView;
@property (weak, nonatomic) IBOutlet UIPickerView *timePickerView;
@property (weak, nonatomic) IBOutlet UIView *metView;
@property (weak, nonatomic) IBOutlet UIView *timeView;

@property (assign, nonatomic) int timelineID;

@property (strong, nonatomic) Timeline *timeline;
@property (strong, nonatomic) NSIndexPath *indexPath;



@end
